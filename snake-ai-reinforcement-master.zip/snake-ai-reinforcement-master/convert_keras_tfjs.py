#Recent import 22/9/18
import tensorflowjs as tfjs
from keras.models import load_model

model = load_model('dqn-final.model')

tfjs.converters.save_keras_model(model, "tfjsv3")
